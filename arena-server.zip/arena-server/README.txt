ARENA server

1. Install Python 3.8+ (python.org).
2. Open a terminal in this folder and run:  python server.py
3. Open http://localhost:8080 (friends on your Wi-Fi use your PC address; the page shows it).
   For internet play run:  ngrok http 8080
